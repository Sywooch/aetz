<?php
return [
    'adminEmail' => 'almalada.kz@mail.ru',
];
