<?php
use common\models\Text;
?>
<footer>
    <div class="cr">
        <span><?= Text::getValue('copyright')?></span>
        <a target="_blank" href="http://astanacreative.kz">Разработка сайтов</a>
    </div>
</footer>