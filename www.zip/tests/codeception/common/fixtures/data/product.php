<?php

return [
    [
        'title' => 'vero',
        'description' => 'Minus eligendi amet saepe voluptatibus.',
        'category_id' => 3,
        'price' => 8,
    ],
    [
        'title' => 'ipsa',
        'description' => 'Omnis necessitatibus et dolores et voluptates id.',
        'category_id' => 4,
        'price' => 7423,
    ],
    [
        'title' => 'beatae',
        'description' => 'Consectetur ut soluta voluptatum id voluptatum voluptas voluptas.',
        'category_id' => 3,
        'price' => 445348714,
    ],
    [
        'title' => 'velit',
        'description' => 'Praesentium aut saepe eum omnis tempore consequatur ut omnis.',
        'category_id' => 7,
        'price' => 7,
    ],
    [
        'title' => 'doloremque',
        'description' => 'Praesentium et eaque enim aut ratione repudiandae.',
        'category_id' => 3,
        'price' => 4540,
    ],
    [
        'title' => 'quae',
        'description' => 'Beatae nesciunt ipsa rerum error.',
        'category_id' => 6,
        'price' => 207,
    ],
    [
        'title' => 'voluptas',
        'description' => 'Quo quis delectus velit ducimus nesciunt quibusdam aliquid.',
        'category_id' => 3,
        'price' => 75202,
    ],
    [
        'title' => 'quia',
        'description' => 'Atque ea sapiente eligendi nisi temporibus reprehenderit.',
        'category_id' => 2,
        'price' => 81118786,
    ],
    [
        'title' => 'voluptatem',
        'description' => 'Explicabo quisquam eveniet et sunt est quasi rerum.',
        'category_id' => 6,
        'price' => 729,
    ],
    [
        'title' => 'tempore',
        'description' => 'Possimus voluptas ea quas est sit distinctio molestiae.',
        'category_id' => 3,
        'price' => 8,
    ],
    [
        'title' => 'nisi',
        'description' => 'Omnis veniam dolore aut consectetur quidem ullam consectetur.',
        'category_id' => 1,
        'price' => 1,
    ],
    [
        'title' => 'ipsa',
        'description' => 'Ut deserunt a alias laudantium consequuntur tempora similique non.',
        'category_id' => 4,
        'price' => 8,
    ],
    [
        'title' => 'aut',
        'description' => 'Deserunt unde eaque qui ut et eveniet et qui veritatis.',
        'category_id' => 6,
        'price' => 21984,
    ],
    [
        'title' => 'molestiae',
        'description' => 'Recusandae rerum aut dignissimos omnis id sed molestias ut officia.',
        'category_id' => 7,
        'price' => 541,
    ],
    [
        'title' => 'ullam',
        'description' => 'Repellendus laborum minima explicabo omnis qui.',
        'category_id' => 4,
        'price' => 517689739,
    ],
    [
        'title' => 'quos',
        'description' => 'Nostrum excepturi quis eveniet laudantium commodi unde.',
        'category_id' => 1,
        'price' => 48,
    ],
    [
        'title' => 'ut',
        'description' => 'Voluptatibus beatae animi perferendis dolore animi saepe dolor enim dolores.',
        'category_id' => 5,
        'price' => 1445,
    ],
    [
        'title' => 'sit',
        'description' => 'Voluptatem qui totam et autem accusamus enim.',
        'category_id' => 5,
        'price' => 5012030,
    ],
    [
        'title' => 'aut',
        'description' => 'Illum ea aliquam omnis quis reprehenderit temporibus.',
        'category_id' => 7,
        'price' => 24,
    ],
    [
        'title' => 'fugiat',
        'description' => 'Ut sit ut quis laboriosam laborum.',
        'category_id' => 7,
        'price' => 120911,
    ],
];
