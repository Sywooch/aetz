<?php

namespace backend\tests\unit;

class DbTestCase extends \yii\codeception\DbTestCase
{
    public $appConfig = '@tests/codeception/config/backend/unit.php';
}
